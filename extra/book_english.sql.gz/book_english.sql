-- MySQL dump 10.13  Distrib 5.1.41, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: bf
-- ------------------------------------------------------
-- Server version	5.1.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_english`
--

DROP TABLE IF EXISTS `book_english`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_english` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `abbreviation_3` char(3) NOT NULL,
  `alternate` char(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_english`
--

/*!40000 ALTER TABLE `book_english` DISABLE KEYS */;
INSERT INTO `book_english` VALUES (1,'Genesis','Gen',''),(2,'Exodus','Exd',''),(3,'Leviticus','Lev',''),(4,'Numbers','Num',''),(5,'Deuteronomy','Deu',''),(6,'Joshua','Jos',''),(7,'Judges','Jdg',''),(8,'Ruth','Rth',''),(9,'1 Samuel','1Sa',''),(10,'2 Samuel','2Sa',''),(11,'1 Kings','1Ki',''),(12,'2 Kings','2Ki',''),(13,'1 Chronicles','1Ch',''),(14,'2 Chronicles','2Ch',''),(15,'Ezra','Ezr',''),(16,'Nehemiah','Neh',''),(17,'Esther','Est',''),(18,'Job','Job',''),(19,'Psalms','Psa',''),(20,'Proverbs','Pro',''),(21,'Ecclesiastes','Ecc',''),(22,'Song of Songs','Sgs',''),(23,'Isaiah','Isa',''),(24,'Jeremiah','Jer',''),(25,'Lamentations','Lam',''),(26,'Ezekiel','Eze',''),(27,'Daniel','Dan',''),(28,'Hosea','Hsa',''),(29,'Joel','Joe',''),(30,'Amos','Amo',''),(31,'Obadiah','Oba',''),(32,'Jonah','Jon',''),(33,'Micah','Mic',''),(34,'Nahum','Nah',''),(35,'Habakkuk','Hab',''),(36,'Zephaniah','Zep',''),(37,'Haggai','Hag',''),(38,'Zechariah','Zec',''),(39,'Malachi','Mal',''),(40,'Matthew','Mat','Matt'),(41,'Mark','Mar','Mark'),(42,'Luke','Luk','Luke'),(43,'John','Jhn','John'),(44,'Acts','Act','Acts'),(45,'Romans','Rom',''),(46,'1 Corinthians','1Cr','1Cor'),(47,'2 Corinthians','2Cr','2Cor'),(48,'Galatians','Gal',''),(49,'Ephesians','Eph',''),(50,'Philippians','Phl','Phil'),(51,'Colossians','Col',''),(52,'1 Thessalonians','1Th','1The'),(53,'2 Thessalonians','2Th','2The'),(54,'1 Timothy','1Ti','1Tim'),(55,'2 Timothy','2Ti','2Tim'),(56,'Titus','Tts',''),(57,'Philemon','Phm','Phlm'),(58,'Hebrews','Hbr',''),(59,'James','Jam','Jas'),(60,'1 Peter','1Pe','1Pet'),(61,'2 Peter','2Pe','2Pet'),(62,'1 John','1Jo','1Joh'),(63,'2 John','2Jo','2Joh'),(64,'3 John','3Jo','3Joh'),(65,'Jude','Jud','Jude'),(66,'Revelation','Rev','');
/*!40000 ALTER TABLE `book_english` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-11-09 18:46:49
